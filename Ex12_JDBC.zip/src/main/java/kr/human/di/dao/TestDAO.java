package kr.human.di.dao;

import java.util.Date;

public interface TestDAO {
	String 	getMessage();
	int 	getResult();
	Date	getToday();
}
