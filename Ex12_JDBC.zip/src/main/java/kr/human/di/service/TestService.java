package kr.human.di.service;

import kr.human.di.vo.TestVO;

public interface TestService {
	TestVO selectTest();
	TestVO selectTest2();
}
