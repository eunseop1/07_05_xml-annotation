package kr.human.di.service;

public interface FileService {
    void readValues();
}