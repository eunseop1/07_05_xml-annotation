package kr.human.di.vo;

public interface Car {
    public void getCarName();
}