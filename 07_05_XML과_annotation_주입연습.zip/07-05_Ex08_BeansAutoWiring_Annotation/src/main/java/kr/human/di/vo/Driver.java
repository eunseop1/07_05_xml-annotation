package kr.human.di.vo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
@Component
public class Driver {
	@Autowired //자동으로 객체를 주입하라. 이게 없으면 xml를 써야 한다. 기본적으로는 byname이다
	//@Autowired(required = false) 만약 하나가 안 넘어올 경우가 생긴다면 다음과 같이 false로 처리해서 작동시킬수 있다 
	private License license;
}
