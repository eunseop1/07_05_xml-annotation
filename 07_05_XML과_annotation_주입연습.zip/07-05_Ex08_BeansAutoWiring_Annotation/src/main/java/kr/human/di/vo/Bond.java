package kr.human.di.vo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Bond {

    @Autowired
    //@Qualifier("mustang")
    @Qualifier("ferari")//동일한 타입의 객체가 복수로 존재할 경우, 객체를 지정해준다
    private Car car;//아무것도 안하면 현재 차 타입이 두개이므로 모호성 에러가 발생

    public void showCar(){
        car.getCarName();
    }
}