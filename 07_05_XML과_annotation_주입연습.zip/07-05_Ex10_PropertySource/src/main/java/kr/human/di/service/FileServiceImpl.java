package kr.human.di.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

@Service("fileService")
public class FileServiceImpl implements FileService{

	//직접 프로퍼티 파일의 내용을 읽는다
	//environment.getProperty를 이용해서 읽는다
	//변수에 대입해준다 없을 경우 기본값 지정 가능
	
	//스프링의 value들이다. 롬복의 것으로 import하지마라
	@Value("${sourceLocation:c:/temp/input}")
    private String source;
 
    @Value("${destinationLocation:c:/temp/output}")
    //destinationLocation라는 항목은 현재 프로퍼티에 없다 -> 적어놓은 기본값을 출력
    private String destination;
 
    @Autowired
    private Environment environment;//환경변수 읽을때 쓰인다
 
    public void readValues() {
        System.out.println("Getting property via Spring Environment :"
                + environment.getProperty("jdbc.driverClassName"));//jdbc.driverClassName를 읽어온다
 
        System.out.println("Source Location : " + source);
        System.out.println("Destination Location : " + destination);
         
    }

}
