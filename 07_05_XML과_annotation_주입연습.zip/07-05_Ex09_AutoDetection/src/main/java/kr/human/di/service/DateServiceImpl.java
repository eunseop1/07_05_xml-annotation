package kr.human.di.service;

import org.joda.time.LocalDate;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;

@Service("dateService")
@Slf4j
public class DateServiceImpl implements DateService{

	@Override
	public LocalDate getNextAssessmentDate() {
		log.info("{} getNextAssessmentDate() 호출", this.getClass().getCanonicalName());
		// 자기 클래스 이름 자동으로 알아내기 
		//-> 다만, sl4j.xml에서 <param name="ConversionPattern" value="%-5p: %c - %m%n" />에서 이미 받아오기에 의미는 없다
		return new LocalDate(2022,07,05);
	}

}
