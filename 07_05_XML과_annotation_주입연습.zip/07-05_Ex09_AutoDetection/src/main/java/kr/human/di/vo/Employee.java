package kr.human.di.vo;

import org.joda.time.LocalDate;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class Employee {
	//vo는 굳이 등록할 필요가 없다. 어파치 서비스와 dao에서 하기에
	private int id;
	 
    private String name;
 
    private LocalDate assessmentDate;
}
